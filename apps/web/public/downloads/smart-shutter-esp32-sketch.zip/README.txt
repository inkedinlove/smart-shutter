Smart Shutter ESP32 Sketch Package

Contents:
- esp32-shutter\esp32-shutter.ino
- esp32-shutter\config.example.h

Quick steps:
1. Open Arduino IDE.
2. Install the ESP32 board package if it is not already present.
3. Open esp32-shutter\esp32-shutter.ino.
4. Copy config.example.h to config.h and edit it before flashing.
5. Select the matching ESP32 board and COM port.
6. Upload, then watch Serial Monitor at 115200.

Site help:
- Open /flash on Smart Shutter for the latest recovery steps.

